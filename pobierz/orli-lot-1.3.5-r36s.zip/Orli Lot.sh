#!/bin/bash
# PORTMASTER: orlilot.zip, Orli Lot.sh
# Orli Lot - skoki narciarskie (natywnie, SDL2).

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

if [ -f "$controlfolder/control.txt" ]; then
  source $controlfolder/control.txt
  [ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
  get_controls
fi

GAMEDIR="$(cd "$(dirname "$0")" && pwd)/orlilot"
> "$GAMEDIR/log.txt" && exec > >(tee "$GAMEDIR/log.txt") 2>&1

cd "$GAMEDIR"
export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"
[ -f "$controlfolder/gamecontrollerdb.txt" ] && export ORLILOT_PADY="$controlfolder/gamecontrollerdb.txt"

./orlilot

type pm_finish > /dev/null 2>&1 && pm_finish
printf "\033c" 2>/dev/null > /dev/tty1
